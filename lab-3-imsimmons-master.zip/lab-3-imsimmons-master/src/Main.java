import java.io.FileNotFoundException;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    static ArrayList<String> records = new ArrayList<>();

    public static void main(String[] args){
        System.out.println(args[0]);
        readFileInfo(args[0]);
    }

    public static void readFileInfo(String fileName){
        System.out.println(fileName);
        try {
            Scanner scan = new Scanner(new File(fileName));
            while(scan.hasNext()){
                String[] info = scan.nextLine().split(",");
                String output = String.format("%10s%10s%10s%10s%10s%10s", info[0], info[1], info[2], info[3], info[4], info[5]);
                System.out.println(output);
                records.add(output);
            }
        } catch (FileNotFoundException e){
            e.printStackTrace();
        }
    }
}
