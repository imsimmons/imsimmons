public class House extends Dwelling {
    private double acreage;
    private int garageSize;

    public double getAcreage() {
        return acreage;
    }

    public void setAcreage(double acreage) {
        this.acreage = acreage;
    }

    public int getGarageSize() {
        return garageSize;
    }

    public void setGarageSize(int garageSize) {
        this.garageSize = garageSize;
    }

    @Override
    public String toString(){
        return "House["+super.toString();
    }
}
