public class Apartment extends Dwelling {
    private String apptNum;
    private boolean laundry;

    public String getApptNum() {
        return apptNum;
    }

    public void setApptNum(String apptNum) {
        this.apptNum = apptNum;
    }

    public boolean isLaundry() {
        return laundry;
    }

    public void setLaundry(boolean laundry) {
        this.laundry = laundry;
    }

    @Override
    public String toString(){
        return "Apartment["+super.toString();
    }
}
