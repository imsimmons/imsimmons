package contactsmodel;

import java.util.ArrayList;

public class ContactList {
    private String listName;
    private ArrayList<Client> clients;

    public String getListName() {
        return listName;
    }

    public void setListName(String listName) {
        this.listName = listName;
    }

    public ArrayList<Client> getClients() {
        return clients;
    }

    public void setClients(ArrayList<Client> clients) {
        this.clients = clients;
    }


}
